import { Queue, Worker } from 'bullmq';
import Redis from 'ioredis';
import { config } from '../config/index.js';
import { createLogger } from '../logger/index.js';
const log = createLogger('QUEUE');
const PHYSICAL_QUEUE = 'sweatyclanker-tasks';
let queue = null;
let worker = null;
const handlers = new Map();

let bullConnection = null;
function getBullConnection() {
  if (!bullConnection) {
    if (!config.redis.url) throw new Error('Redis not connected');
    bullConnection = new Redis(config.redis.url, {
      maxRetriesPerRequest: null,
      enableReadyCheck: false,
    });
    bullConnection.on('error', (err) => log.error('BullMQ Redis connection error', err));
  }
  return bullConnection;
}

export function getQueue(name) {
  if (!queue) queue = new Queue(PHYSICAL_QUEUE, { connection: getBullConnection() });
  return queue;
}
export function enqueueTask(queueName, data, opts = {}) {
  const queue = getQueue(queueName);
  return queue.add(queueName, data, {
    attempts: 3,
    backoff: { type: 'exponential', delay: 2000 },
    removeOnComplete: { age: 3600, count: 100 },
    removeOnFail: { age: 86400, count: 100 },
    ...opts,
  });
}
export function startWorker(queueName, handler, concurrency = 1) {
  handlers.set(queueName, handler);
  if (worker) return worker;
  worker = new Worker(PHYSICAL_QUEUE, async job => {
    const selected = handlers.get(job.name);
    if (!selected) throw new Error(`No handler registered for ${job.name}`);
    log.info(`Processing job ${job.name}:${job.id}`);
    try { return await selected(job.data, job); }
    catch (err) { log.error(`Job ${job.id} failed: ${err.message}`); throw err; }
  }, { connection: getBullConnection(), concurrency });
  worker.on('completed', job => log.info(`Job ${job.id} completed`));
  worker.on('failed', (job, err) => log.error(`Job ${job.id} failed`, err));
  return worker;
}
export async function drainQueues() {
  if (worker) { await worker.close(); worker = null; }
  if (queue) { await queue.close(); queue = null; }
  if (bullConnection) { await bullConnection.quit(); bullConnection = null; }
}
