import axios from 'axios';
import fs from 'fs/promises';
import path from 'path';
import { createLogger } from '../logger/index.js';
import { config } from '../config/index.js';
import { DeepSeekClient } from '../ai/client.js';
import { getRedis } from '../storage/redis.js';
import { enqueueTask } from './index.js';
const log = createLogger('WORKER');

const ai = new DeepSeekClient();
const outputDir = path.resolve(config.workers.outputDir || 'worker-output');

function required(value, name) {
  if (value === undefined || value === null || value === '') throw new Error(`Missing required job field: ${name}`);
  return value;
}

function safeName(value) { return String(value || 'job').replace(/[^a-z0-9_-]/gi, '_').slice(0, 80); }

async function saveResult(type, id, result) {
  await fs.mkdir(outputDir, { recursive: true });
  const filename = `${type}-${safeName(id)}.json`;
  await fs.writeFile(path.join(outputDir, filename), JSON.stringify(result, null, 2));
  return filename;
}

async function postWebhook(url, payload, label) {
  if (!url) throw new Error(`${label} integration is not configured`);
  const response = await axios.post(url, payload, { timeout: 20000, maxRedirects: 2 });
  return { status: response.status, data: response.data };
}

function parseJson(text) {
  const cleaned = String(text).replace(/^```(?:json)?/i, '').replace(/```$/i, '').trim();
  try { return JSON.parse(cleaned); }
  catch { return { raw: String(text).slice(0, 4000) }; }
}

async function analyzeVod(data) {
  const vodId = required(data.vodId, 'vodId');
  const source = data.transcript || data.chatLog || data.description || data.title;
  required(source, 'transcript, chatLog, description, or title');
  const prompt = [
    { role: 'system', content: 'Analyze a gaming VOD. Return JSON only with keys summary, highlights (array of {startSeconds,endSeconds,title,reason,score}), socialCaption, and thumbnailText. Select at most 5 strong moments.' },
    { role: 'user', content: JSON.stringify({ vodId, channel: data.channel, title: data.title, duration: data.duration, source: String(source).slice(0, 30000) }) },
  ];
  const analysis = parseJson(await ai.chat(prompt, { temperature: 0.25, maxTokens: 1400 }));
  const result = { type: 'analyze-vod', vodId, channel: data.channel, analysis, createdAt: new Date().toISOString() };
  await saveResult('analysis', vodId, result);
  if (Array.isArray(analysis.highlights) && analysis.highlights.length) {
    await enqueueTask('generate-clips', { ...data, timestamps: analysis.highlights, analysis }, { jobId: `clips-${safeName(vodId)}` });
  }
  await enqueueTask('stream-summary', { ...data, analysis }, { jobId: `summary-${safeName(vodId)}` });
  return result;
}

async function generateClips(data) {
  const vodId = required(data.vodId, 'vodId');
  const timestamps = required(data.timestamps, 'timestamps');
  if (!Array.isArray(timestamps) || !timestamps.length) throw new Error('timestamps must be a non-empty array');
  const response = await postWebhook(config.workers.clipWebhookUrl, { vodId, vodUrl: data.vodUrl, timestamps, channel: data.channel }, 'CLIP_WEBHOOK_URL');
  const clips = response.data?.clips || response.data || [];
  const result = { type: 'generate-clips', vodId, clips, createdAt: new Date().toISOString() };
  await saveResult('clips', vodId, result);
  const first = Array.isArray(clips) ? clips[0] : null;
  if (first) await enqueueTask('create-thumbnail', { videoId: first.id || vodId, timestamp: timestamps[0], clip: first, analysis: data.analysis });
  return result;
}

async function createThumbnail(data) {
  const videoId = required(data.videoId, 'videoId');
  const payload = { videoId, timestamp: data.timestamp, clip: data.clip, text: data.analysis?.thumbnailText, style: 'SweatyClanker gold-chrome gaming thumbnail, high contrast, readable on mobile' };
  const response = await postWebhook(config.workers.thumbnailWebhookUrl, payload, 'THUMBNAIL_WEBHOOK_URL');
  const result = { type: 'create-thumbnail', videoId, thumbnail: response.data, createdAt: new Date().toISOString() };
  await saveResult('thumbnail', videoId, result);
  return result;
}

async function streamSummary(data) {
  const channel = required(data.channel, 'channel');
  let summary = data.analysis?.summary;
  let socialCaption = data.analysis?.socialCaption;
  if (!summary) {
    const response = await ai.chat([
      { role: 'system', content: 'Write a concise gaming stream recap and a short social caption. Return JSON only with summary and socialCaption.' },
      { role: 'user', content: JSON.stringify({ channel, duration: data.duration, title: data.title, transcript: String(data.transcript || '').slice(0, 20000) }) },
    ], { temperature: 0.4, maxTokens: 600 });
    ({ summary, socialCaption } = parseJson(response));
  }
  const id = data.vodId || `${channel}-${Date.now()}`;
  const result = { type: 'stream-summary', channel, vodId: data.vodId, summary, socialCaption, createdAt: new Date().toISOString() };
  await saveResult('summary', id, result);
  if (socialCaption && config.workers.socialWebhookUrl) await enqueueTask('post-social', { platform: 'configured', content: socialCaption, vodId: data.vodId });
  if (summary && config.workers.discordWebhookUrl) await enqueueTask('discord-announce', { channel, message: summary, vodId: data.vodId });
  return result;
}

async function postSocial(data) {
  required(data.platform, 'platform');
  required(data.content, 'content');
  const response = await postWebhook(config.workers.socialWebhookUrl, data, 'SOCIAL_WEBHOOK_URL');
  return { type: 'post-social', platform: data.platform, status: response.status, createdAt: new Date().toISOString() };
}

async function discordAnnounce(data) {
  const message = required(data.message, 'message');
  const response = await postWebhook(config.workers.discordWebhookUrl, { content: String(message).slice(0, 2000) }, 'DISCORD_WEBHOOK_URL');
  return { type: 'discord-announce', channel: data.channel, status: response.status, createdAt: new Date().toISOString() };
}

async function moderationReview(data) {
  required(data.message, 'message');
  const response = await ai.chat([
    { role: 'system', content: 'Review Twitch chat safety. Return JSON only: {decision:"allow"|"flag"|"urgent",categories:[],confidence:0-1,reason:""}. Never recommend punishment solely from uncertain context.' },
    { role: 'user', content: JSON.stringify({ channel: data.channel, user: data.user, message: data.message, reason: data.reason, riskScore: data.riskScore }) },
  ], { temperature: 0, maxTokens: 250 });
  const review = parseJson(response);
  const id = `${data.channel || 'channel'}-${data.user || 'user'}-${Date.now()}`;
  const result = { type: 'moderation-review', ...data, review, reviewedAt: new Date().toISOString() };
  await saveResult('moderation', id, result);
  return result;
}

async function memoryCleanup() {
  const redis = getRedis();
  if (!redis) return { type: 'memory-cleanup', skipped: true, reason: 'Redis unavailable' };
  let cursor = '0';
  let scanned = 0;
  let removed = 0;
  do {
    const [next, keys] = await redis.scan(cursor, 'MATCH', 'profile:*', 'COUNT', 100);
    cursor = next;
    scanned += keys.length;
    if (keys.length) {
      const pipeline = redis.pipeline();
      keys.forEach(key => pipeline.ttl(key));
      const ttls = await pipeline.exec();
      const stale = keys.filter((_, index) => Number(ttls[index]?.[1]) === -1);
      if (stale.length) { await redis.unlink(...stale); removed += stale.length; }
    }
  } while (cursor !== '0' && scanned < 1000);
  return { type: 'memory-cleanup', scanned, removed, createdAt: new Date().toISOString() };
}

export const jobHandlers = {
  'analyze-vod': analyzeVod,
  'generate-clips': generateClips,
  'create-thumbnail': createThumbnail,
  'stream-summary': streamSummary,
  'post-social': postSocial,
  'discord-announce': discordAnnounce,
  'moderation-review': moderationReview,
  'memory-cleanup': memoryCleanup,
};
