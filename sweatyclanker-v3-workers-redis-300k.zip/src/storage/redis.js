import Redis from 'ioredis';
import { config } from '../config/index.js';
import { createLogger } from '../logger/index.js';
const log = createLogger('REDIS');
let redis = null;
let estimatedCommands = 0;
let budgetWarningSent = false;
export async function connectRedis() {
  if (!config.redis.url) {
    log.warn('No REDIS_URL provided, using file storage fallback');
    return null;
  }
  redis = new Redis(config.redis.url, {
    retryStrategy(times) {
      const delay = Math.min(times * 50, 2000);
      log.warn(`Redis reconnect attempt ${times}, delay ${delay}ms`);
      return delay;
    },
    maxRetriesPerRequest: 3,
  });
  const originalSendCommand = redis.sendCommand.bind(redis);
  redis.sendCommand = function budgetedSendCommand(command, stream) {
    const name = String(command?.name || '').toLowerCase();
    // Connection maintenance is required to recover cleanly and is not blocked.
    if (!['auth', 'hello', 'quit', 'ping'].includes(name)) estimatedCommands++;
    const cutoff = Math.max(0, config.redis.monthlyCommandLimit - config.redis.safetyReserve);
    if (cutoff && estimatedCommands >= cutoff) {
      if (!budgetWarningSent) {
        budgetWarningSent = true;
        log.error(`Redis safety cutoff reached at ${estimatedCommands} estimated commands; nonessential writes are disabled`);
      }
      if (['set', 'setex', 'mset', 'del', 'unlink', 'expire', 'lpush', 'rpush', 'ltrim', 'hset', 'incr', 'incrby'].includes(name)) {
        return Promise.reject(new Error('Redis monthly command safety cutoff reached'));
      }
    }
    return originalSendCommand(command, stream);
  };
  redis.on('connect', () => log.info('Connected to Redis'));
  redis.on('error', (err) => log.error('Redis error', err));
  redis.on('close', () => log.warn('Redis connection closed'));
  await redis.ping();
  return redis;
}
export function getRedis() { return redis; }
export function getRedisBudget() {
  return {
    estimatedCommands,
    limit: config.redis.monthlyCommandLimit,
    safetyReserve: config.redis.safetyReserve,
    cutoff: Math.max(0, config.redis.monthlyCommandLimit - config.redis.safetyReserve),
  };
}
