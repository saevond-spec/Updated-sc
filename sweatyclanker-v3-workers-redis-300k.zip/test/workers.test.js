import test from 'node:test';
import assert from 'node:assert/strict';

process.env.TWITCH_USERNAME ||= 'testbot';
process.env.TWITCH_CLIENT_ID ||= 'test-client';
process.env.TWITCH_CLIENT_SECRET ||= 'test-secret';
process.env.JOIN_CHANNELS ||= 'saevond';
process.env.DEEPSEEK_API_KEY ||= 'test-deepseek-key';
process.env.EVENTSUB_SECRET ||= 'test-eventsub-secret';
process.env.WORKERS_ENABLED ||= 'true';

const { jobHandlers } = await import('../src/queue/handlers.js');

test('all eight real worker handlers are registered', () => {
  assert.deepEqual(Object.keys(jobHandlers).sort(), [
    'analyze-vod',
    'create-thumbnail',
    'discord-announce',
    'generate-clips',
    'memory-cleanup',
    'moderation-review',
    'post-social',
    'stream-summary',
  ]);
  for (const handler of Object.values(jobHandlers)) assert.equal(typeof handler, 'function');
});

test('workers reject incomplete jobs instead of logging fake success', async () => {
  await assert.rejects(jobHandlers['analyze-vod']({ channel: 'saevond' }), /vodId/);
  await assert.rejects(jobHandlers['generate-clips']({ vodId: '1' }), /timestamps/);
  await assert.rejects(jobHandlers['create-thumbnail']({}), /videoId/);
  await assert.rejects(jobHandlers['stream-summary']({}), /channel/);
  await assert.rejects(jobHandlers['post-social']({}), /platform/);
  await assert.rejects(jobHandlers['discord-announce']({}), /message/);
  await assert.rejects(jobHandlers['moderation-review']({}), /message/);
});

test('memory cleanup safely skips when Redis is unavailable', async () => {
  const result = await jobHandlers['memory-cleanup']({});
  assert.equal(result.skipped, true);
});
